plugins { id("com.android.application") }

android {
    namespace = "com.gameguard"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gameguard"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
