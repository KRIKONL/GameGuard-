package com.gameguard;

import android.app.Activity;
import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Typeface;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

public class MainActivity extends Activity {
    private TextView permission, recent;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        int pad = dp(22);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(36), pad, pad);
        root.setBackgroundColor(0xFF101318);

        TextView title = new TextView(this);
        title.setText("GameGuard");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Gaming mode • Early preview");
        subtitle.setTextColor(0xFFB8C1CE);
        subtitle.setTextSize(15);
        root.addView(subtitle);

        permission = info(root, "Usage access: checking…");
        recent = info(root, "Recent app: not checked");

        Button grant = new Button(this);
        grant.setText("Grant usage access");
        grant.setOnClickListener(v -> startActivity(
            new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
        root.addView(grant, new LinearLayout.LayoutParams(-1, -2));

        Button refresh = new Button(this);
        refresh.setText("Refresh status");
        refresh.setOnClickListener(v -> refreshStatus());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(10);
        root.addView(refresh, rp);

        TextView warning = new TextView(this);
        warning.setText("Preview only: this version checks usage access and recent app activity when opened. It does not stop or restrict apps. Automatic detection and reversible Extreme mode are not implemented yet.");
        warning.setTextColor(0xFFFFD28A);
        warning.setTextSize(14);
        warning.setPadding(0, dp(24), 0, 0);
        root.addView(warning);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        if (permission != null) refreshStatus();
    }

    private TextView info(LinearLayout root, String value) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(0xFFE6EAF0);
        t.setTextSize(17);
        t.setPadding(0, dp(22), 0, dp(8));
        root.addView(t);
        return t;
    }

    private boolean hasUsageAccess() {
        AppOpsManager ops = (AppOpsManager)getSystemService(Context.APP_OPS_SERVICE);
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }

    private void refreshStatus() {
        boolean allowed = hasUsageAccess();
        permission.setText("Usage access: " + (allowed ? "Granted" : "Not granted"));
        recent.setText(allowed ? "Recent app: " + recentApp() :
            "Grant Usage Access to view recent app activity.");
    }

    private String recentApp() {
        UsageStatsManager manager =
            (UsageStatsManager)getSystemService(Context.USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        List<UsageStats> list = manager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY, now - 3600000L, now);
        if (list == null || list.isEmpty()) return "No recent usage data";
        UsageStats newest = null;
        for (UsageStats item : list)
            if (newest == null || item.getLastTimeUsed() > newest.getLastTimeUsed())
                newest = item;
        if (newest == null || newest.getLastTimeUsed() == 0) return "No recent usage data";
        String[] parts = newest.getPackageName().split("\\.");
        return parts[parts.length - 1];
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }
}
