# GameGuard
Early Android gaming-assistant prototype for Xiaomi HyperOS.

## Current scope
This initial preview provides a dashboard and a Usage Access permission helper.
It does not yet automatically detect game launches, restrict background apps, or restore AppOps settings.
Those capabilities require a tested Shizuku integration and must not be treated as implemented.

## Build
The included GitHub Actions workflow builds a debug APK on pushes and manual workflow runs.
Download `GameGuard-debug-apk` from a successful run under the repository's Actions tab.
